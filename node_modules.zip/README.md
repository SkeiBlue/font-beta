﻿# FONT V2

Backend Node.js (Fastify + PostgreSQL)  roadmap v7.

## Prérequis

- Node.js + npm
- PostgreSQL
- Windows PowerShell (ou équivalent)

## Installation

### 1) Cloner et installer

```bash
git clone <repo>
cd FONT-V2
cd backend
npm install
